/** Automatically generated file. DO NOT MODIFY */
package blr.tsyvaniukvasili.numergame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}