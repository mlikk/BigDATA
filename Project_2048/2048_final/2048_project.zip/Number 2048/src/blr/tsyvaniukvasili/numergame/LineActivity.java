package blr.tsyvaniukvasili.numergame;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.SeriesSelection;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class LineActivity extends Activity {
	int total,lc,rc,dc,uc;
	
    private GraphicalView mChart;
    
    private String[] mMonth = new String[] {};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_line);
		openChart();
	}
	private void GenerateReport(){
		 
		String move; 
		BufferedReader br = null;
	       File sdCard = Environment.getExternalStorageDirectory();
	 		try {
	  
	 			String sCurrentLine;
	 			br = new BufferedReader(new FileReader(sdCard.getAbsolutePath() + "/Data/sensorkmk.txt"));
	  
	 			while ((sCurrentLine = br.readLine()) != null) {
	 				
	 				if(sCurrentLine.equals(""))
	 				{
	 					continue;
	 				}
	 				
	 				String[] array = sCurrentLine.split("\t");
	 				
	 				move = array[0];
	 				
	 				if(move.equals("1")){
	 					lc++;
	 				}
	 				else if(move.equals("2")){	
						rc++;
						
	 				}
	 				else if(move.equals("3")){
	 					
						
						uc++;
	 				}
	 				else
	 					{
						
	 					dc++;
	 					}
	 				
	 				
	 			}
	 			total= lc+rc+dc+uc;
	 			
	 		}	
	 		catch (Exception e) {
	               e.printStackTrace();
	        }
	 				
}

	 
    private void openChart(){
    	
    	GenerateReport();
    	int[] x = new int[total];
    	String[] moves = new String[total]; 
    	int n=total;
        for(int i=0; i<n-1;i++)
        {
        	x[i]=i;
        }
        BufferedReader br = null;
	       File sdCard = Environment.getExternalStorageDirectory();
	 		try {
	  
	 			String sCurrentLine;
	 			int i=0;
	 			br = new BufferedReader(new FileReader(sdCard.getAbsolutePath() + "/Data/sensorkmk.txt"));
	  
	 			while ((sCurrentLine = br.readLine()) != null) {
	 				
	 				if(sCurrentLine.equals(""))
	 				{
	 					continue;
	 				}
	 				
	 				String[] array = sCurrentLine.split("\t");
	 				
	 				moves[i] = array[0];
	 				i++;
	 			}
	 		}
	 		catch (Exception e) {
	               e.printStackTrace();
	        }
        
        //int[] expense = {2200, 2700, 2900, 2800, 2600, 3000, 3300, 3400 };
 
        // Creating an  XYSeries for moves
        XYSeries movesSeries = new XYSeries("moves");
        // Creating an  XYSeries for Expense
       // XYSeries expenseSeries = new XYSeries("Expense");
        // Adding data to moves and Expense Series
        for(int j=0;j<n-1;j++){
           movesSeries.add(x[j],Integer.parseInt(moves[j]));
        }
        XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
        // Adding moves Series to the dataset
        dataset.addSeries(movesSeries);
        // Adding Expense Series to dataset
        //dataset.addSeries(expenseSeries);
 
        // Creating XYSeriesRenderer to customize movesSeries
        XYSeriesRenderer movesRenderer = new XYSeriesRenderer();
        movesRenderer.setColor(Color.WHITE);
        movesRenderer.setPointStyle(PointStyle.CIRCLE);
        movesRenderer.setFillPoints(true);
        movesRenderer.setLineWidth(0);
        movesRenderer.setDisplayChartValues(true);
 /*
        // Creating XYSeriesRenderer to customize expenseSeries
        XYSeriesRenderer expenseRenderer = new XYSeriesRenderer();
        expenseRenderer.setColor(Color.YELLOW);
        expenseRenderer.setPointStyle(PointStyle.CIRCLE);
        expenseRenderer.setFillPoints(true);
        expenseRenderer.setLineWidth(2);
        expenseRenderer.setDisplayChartValues(true);
 */
        // Creating a XYMultipleSeriesRenderer to customize the whole chart
        XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
        multiRenderer.setXLabels(0);
        multiRenderer.setChartTitle("sequence of moves made");
        multiRenderer.setXTitle("step");
        multiRenderer.setYTitle("move made");
        multiRenderer.setZoomButtonsVisible(true);
        for(int j=0;j<x.length;j++){
            multiRenderer.addXTextLabel(j,String.valueOf(j));
        }
 
      // Adding movesRenderer and expenseRenderer to multipleRenderer
        // Note: The order of adding dataseries to dataset and renderers to multipleRenderer
        // should be same
        multiRenderer.addSeriesRenderer(movesRenderer);
   //     multiRenderer.addSeriesRenderer(expenseRenderer);
 
        // Getting a reference to LinearLayout of the MainActivity Layout
        LinearLayout chartContainer = (LinearLayout) findViewById(R.id.chart_container);
 
        // Creating a Line Chart
        mChart = (GraphicalView) ChartFactory.getLineChartView(getBaseContext(), dataset, multiRenderer);
 
        multiRenderer.setClickEnabled(true);//
        multiRenderer.setSelectableBuffer(10);
        mChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SeriesSelection seriesSelection = mChart.getCurrentSeriesAndPoint();
 
                if (seriesSelection != null) {
                    int seriesIndex = seriesSelection.getSeriesIndex();
                    String selectedSeries="moves";
                    // Getting the clicked Month
                    String month = mMonth[(int)seriesSelection.getXValue()];
                    // Getting the y value
                    int amount = (int) seriesSelection.getValue();
                    Toast.makeText(
                        getBaseContext(),
                        selectedSeries + " in "  + month + " : " + amount ,
                        Toast.LENGTH_SHORT).show();
                }
            }
        });
 
        // Adding the Line Chart to the LinearLayout
        chartContainer.addView(mChart);
    }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.line, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
