package blr.tsyvaniukvasili.numergame;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import blr.tsyvaniukvasili.numergame.MainActivity;

import org.achartengine.ChartFactory;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class PieActivity extends Activity {

	MainActivity ma;
	int lc;
	int rc,dc,uc;
	double[] distribution;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pie);
		openChart();
	}
	
		private void GenerateReport(){
			 
		    int lastScore=0;
			BufferedReader br = null;
		       File sdCard = Environment.getExternalStorageDirectory();
		        //File directory = new File (sdCard.getAbsolutePath() + "/Data/sensorkmk.txt");
		        //if(!directory.exists())
		        //directory.mkdirs();
		        //String fname = "sensorkmk.txt";
		        //File file = new File (directory, fname);
		 		try {
		  
		 			String sCurrentLine;
		  
		 			br = new BufferedReader(new FileReader(sdCard.getAbsolutePath() + "/Data/sensorkmk.txt"));
		  
		 			while ((sCurrentLine = br.readLine()) != null) {
		 				
		 				 //Put p = new Put(Bytes.toBytes("row1"),timestamp);
		 				
		 				if(sCurrentLine.equals(""))
		 				{
		 					continue;
		 				}
		 				
		 				String[] array = sCurrentLine.split("\t");
		 				String move = array[0];
		 				System.out.println(move);
		 				if(move.equals("1")){
		 					
							lc++;
		 				}
		 				else if(move.equals("2")){
		 					
							rc++;
		 				}
		 				else if(move.equals("3")){
		 					
							uc++;
		 				}
		 				else dc++;
		 			
		 				
		 				
		 			}
		 		
		 		}
		 		catch (Exception e) {
		               e.printStackTrace();
		        }
		 				
	}
	
	 private void openChart(){
		 
	        // Pie Chart Section Names
	        String[] code = new String[] {
	            "no.of left moves", "no.of right moves", "no.of up moves", "no.of down moves "
	        };
	        GenerateReport();
	       //get();
	        //int[] tion =ma.get();
	        System.out.println(lc +" "+ uc + " "+ dc +" "+ rc); 
	        // Pie Chart Section Value
	        double[] distribution= {lc,rc,uc,dc};
	 
	        // Color of each Pie Chart Sections
	        int[] colors = { Color.BLUE, Color.MAGENTA, Color.GREEN, Color.CYAN};
	 
	        // Instantiating CategorySeries to plot Pie Chart
	        CategorySeries distributionSeries = new CategorySeries(" Android version distribution as on October 1, 2012");
	        for(int i=0 ;i < distribution.length;i++){
	            // Adding a slice with its values and name to the Pie Chart
	            distributionSeries.add(code[i], distribution[i]);
	        }
	 
	        // Instantiating a renderer for the Pie Chart
	        DefaultRenderer defaultRenderer  = new DefaultRenderer();
	        for(int i = 0 ;i<distribution.length;i++){
	            SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();
	            seriesRenderer.setColor(colors[i]);
	            seriesRenderer.setDisplayChartValues(true);
	            // Adding a renderer for a slice
	            defaultRenderer.addSeriesRenderer(seriesRenderer);
	        }
	 
	        defaultRenderer.setChartTitle("2048 moves, 14");
	        defaultRenderer.setChartTitleTextSize(20);
	        defaultRenderer.setZoomButtonsVisible(true);
	 
	        // Creating an intent to plot bar chart using dataset and multipleRenderer
	        Intent intent = ChartFactory.getPieChartIntent(getBaseContext(), distributionSeries , defaultRenderer, "2048 moves");
	 
	        // Start Activity
	        startActivity(intent);
	 
	    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.pie, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
